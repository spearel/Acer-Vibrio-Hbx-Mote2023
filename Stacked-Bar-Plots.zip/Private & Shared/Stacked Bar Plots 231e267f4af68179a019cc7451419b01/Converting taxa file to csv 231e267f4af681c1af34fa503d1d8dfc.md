# Converting taxa file to csv

```jsx

OTU_1 = as(otu_table(ps),"matrix")
if(taxa_are_rows(ps)){OTU_1 <- t(OTU_1)}
OTU_1_df = as.data.frame(OTU_1)

write.csv(OTU_1_df, 
	
	
	
	
```