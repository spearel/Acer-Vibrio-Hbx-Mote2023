# Alpha & Beta Diversity

**Alpha Diversity**

The code below will measure the following alpha diversity metrics (only on rarefied data)

Observed richness (ASVs), Shannon, Simpson, and Evenness

Visualization and stats were done in GraphPad

```jsx
#Only analyze rarefied data for alpha diversity
#rare45 (ps.rare45)

alpha.diversity.rare45 <- estimate_richness(ps.rare45,split=TRUE, measure =c("Shannon","Observed","Simpson"))
alpha.diversity.rare45
valueH <- alpha.diversity.rare45$Shannon
valueS1 <- alpha.diversity.rare45$Observed
valueS <- log(valueS1)
evenness <-valueH/valueS
evenness
alpha.diversity.rare45$Evenness=evenness
alpha.diversity.rare45

write.csv(alpha.diversity.rare45,"alpha.diversity.rare45.csv")
```

**Beta Diversity**

The code below will measure the following beta diversity metrics (only on unrarefied data)

```jsx
#plot_ordination arguments

plot_ordination(physeq, ordination, type ="samples", axes=1:2m color=NULL, shape=NULL, label=NULL, title=NULL, justDF=FALSE)

#physeq: ps object
#ordination: method of orgination, no default
#type: method to differentiate between samples; think "time", "treatment"

#default confidence level is 0.95. To alter, add argument 'level="0.##"'

```

#Betadiversity analyses was done on unrarefied data 

Unrare Data

```jsx
#Unrare (ps.noBlank)

#Microbial Abundance (Bray-Curtis)
		# Transform data to proportions as appropriate for Bray-Curtis distances
ps.prop.unrare <- transform_sample_counts(ps.noBlank, function(otu) otu/sum(otu))
ord.nmds.bray.unrare <- ordinate(ps.prop.unrare, method="NMDS", distance="bray")
    
ordplot.unrare <-plot_ordination(ps.prop.unrare, ord.nmds.bray.unrare, color="TreatTime", title="Bray NMDS")
ordplot.unrare +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
```

Plots are generated including all samples, as well as subsampled by time and treatment. 

Subsetting samples

```jsx
#Base script

#code to **remove** a set of samples
ps.output-object <-subset_samples(ps.oringinal-object, Treatment != "samples-to-remove")

#code to **keep** only a set of samples
ps.output-object <-subset_samples(ps.oringinal-object, Treatment == "samples-to-keep")
```

**Separating by Time**

```jsx
#Day 0
ps.unrare.0days <-subset_samples(ps.noBlank, Time == "0")
ps.prop.unrare.0days <- transform_sample_counts(ps.unrare.0days, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.0days <- ordinate(ps.prop.unrare.0days, method="NMDS", distance="bray")
    
ordplot.unrare.0days <-plot_ordination(ps.prop.unrare.0days, ord.nmds.bray.unrare.0days, color="TreatTime", title="Bray NMDS")
ordplot.unrare.0days +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
	
#Day 1
ps.unrare.1days <-subset_samples(ps.noBlank, Time == "1")
ps.prop.unrare.1days <- transform_sample_counts(ps.unrare.1days, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.1days <- ordinate(ps.prop.unrare.1days, method="NMDS", distance="bray")
    
ordplot.unrare.1days <-plot_ordination(ps.prop.unrare.1days, ord.nmds.bray.unrare.1days, color="TreatTime", title="Bray NMDS")
ordplot.unrare.1days +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
	
#Day 4
ps.unrare.4days <-subset_samples(ps.noBlank, Time == "4")
ps.prop.unrare.4days <- transform_sample_counts(ps.unrare.4days, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.4days <- ordinate(ps.prop.unrare.4days, method="NMDS", distance="bray")
    
ordplot.unrare.4days <-plot_ordination(ps.prop.unrare.4days, ord.nmds.bray.unrare.4days, color="TreatTime", title="Bray NMDS")
ordplot.unrare.4days +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
```

**Separating by Treatment**

```jsx
#No inoculation control
ps.unrare.N <-subset_samples(ps.noBlank, Treatment == "N")
ps.prop.unrare.N <- transform_sample_counts(ps.unrare.N, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.N <- ordinate(ps.prop.unrare.N, method="NMDS", distance="bray")
    
ordplot.unrare.N <-plot_ordination(ps.prop.unrare.N, ord.nmds.bray.unrare.N, color="TreatTime", title="Bray NMDS")
ordplot.unrare.N +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
	
#HBX only
ps.unrare.H <-subset_samples(ps.noBlank, Treatment == "H")
ps.prop.unrare.H <- transform_sample_counts(ps.unrare.H, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.H <- ordinate(ps.prop.unrare.H, method="NMDS", distance="bray")
    
ordplot.unrare.H <-plot_ordination(ps.prop.unrare.H, ord.nmds.bray.unrare.H, color="TreatTime", title="Bray NMDS")
ordplot.unrare.H +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
	
#VC only
ps.unrare.V <-subset_samples(ps.noBlank, Treatment == "V")
ps.prop.unrare.V <- transform_sample_counts(ps.unrare.V, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.V <- ordinate(ps.prop.unrare.V, method="NMDS", distance="bray")
    
ordplot.unrare.V <-plot_ordination(ps.prop.unrare.V, ord.nmds.bray.unrare.V, color="TreatTime", title="Bray NMDS")
ordplot.unrare.V +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
	
	
#VC + HBX 
ps.unrare.B <-subset_samples(ps.noBlank, Treatment == "B")
ps.prop.unrare.B <- transform_sample_counts(ps.unrare.B, function(otu) otu/sum(otu))
ord.nmds.bray.unrare.B <- ordinate(ps.prop.unrare.B, method="NMDS", distance="bray")
    
ordplot.unrare.B <-plot_ordination(ps.prop.unrare.B, ord.nmds.bray.unrare.B, color="TreatTime", title="Bray NMDS")
ordplot.unrare.B +
	stat_ellipse(type="t", linetype=2) +
	theme_bw()
```

**Stats - PERMANOVA** 

Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

```jsx
**#Comparing both time and treats**
bray_dist_unrare = phyloseq::distance(ps.noBlank, method="bray")
adonis2(bray_dist_unrare ~sample_data(ps.noBlank)$TreatTime)
#####                                  Df SumOfSqs      R2     F Pr(>F)    
sample_data(ps.noBlank)$TreatTime 11  14.7762 0.82241 29.89  0.001 ***
Residual                          71   3.1908 0.17759                 
Total                             82  17.9670 1.00000                 

**###Comparing treats within a given time**
bray_dist_unrare.0days = phyloseq::distance(ps.unrare.0days, method="bray")
adonis2(bray_dist_unrare.0days ~sample_data(ps.unrare.0days)$TreatTime)
#####                                       Df SumOfSqs      R2      F Pr(>F)
sample_data(ps.unrare.0days)$TreatTime  3 0.004781 0.03178 0.2626  0.955
Residual                               24 0.145652 0.96822              
Total                                  27 0.150433 1.00000  

bray_dist_unrare.1days = phyloseq::distance(ps.unrare.1days, method="bray")
adonis2(bray_dist_unrare.1days ~sample_data(ps.unrare.1days)$TreatTime)
#####                                       Df SumOfSqs      R2      F Pr(>F)    
sample_data(ps.unrare.1days)$TreatTime  3   4.9781 0.79654 30.015  0.001 ***
Residual                               23   1.2715 0.20346                  
Total                                  26   6.2497 1.00000                  

bray_dist_unrare.4days = phyloseq::distance(ps.unrare.4days, method="bray")
adonis2(bray_dist_rare45.4days ~sample_data(ps.unrare.4days)$TreatTime)
#####                                       Df SumOfSqs      R2      F Pr(>F)    
sample_data(ps.unrare.4days)$TreatTime  3   5.7693 0.77135 26.988  0.001 ***
Residual                               24   1.7102 0.22865                  
Total                                  27   7.4795 1.00000                  

**#Comparing time between treats**

bray_dist_unrare.N = phyloseq::distance(ps.unrare.N, method="bray")
adonis2(bray_dist_unrare.N ~sample_data(ps.unrare.N)$TreatTime)
######                                   Df SumOfSqs      R2      F Pr(>F)
sample_data(ps.unrare.N)$TreatTime  2 0.004675 0.02285 0.2105  0.948
Residual                           18 0.199893 0.97715              
Total                              20 0.204568 1.00000  

bray_dist_unrare.H = phyloseq::distance(ps.unrare.H, method="bray")
adonis2(bray_dist_unrare.H ~sample_data(ps.unrare.H)$TreatTime)
#####                                   Df SumOfSqs      R2      F Pr(>F)  
sample_data(ps.unrare.H)$TreatTime  2 0.066271 0.30599 3.9681  0.017 *
Residual                           18 0.150309 0.69401                
Total                              20 0.216580 1.00000                

bray_dist_unrare.V = phyloseq::distance(ps.unrare.V, method="bray")
adonis2(bray_dist_unrare.V ~sample_data(ps.unrare.V)$TreatTime)
#####                                   Df SumOfSqs      R2      F Pr(>F)    
sample_data(ps.unrare.V)$TreatTime  2   4.2644 0.81994 38.706  0.001 ***
Residual                           17   0.9365 0.18006                  
Total                              19   5.2009 1.00000                  

bray_dist_unrare.B = phyloseq::distance(ps.unrare.B, method="bray")
adonis2(bray_dist_unrare.B ~sample_data(ps.unrare.B)$TreatTime)
#####                                   Df SumOfSqs      R2      F Pr(>F)    
sample_data(ps.unrare.B)$TreatTime  2   4.1864 0.68737 19.788  0.001 ***
Residual                           18   1.9041 0.31263                  
Total                              20   6.0905 1.00000                  
```

**Stats - betadisper**

```jsx
permutest(beta.unrare<-betadisper(bray_dist_unrare, sample_data(ps.noBlank)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df  Sum Sq  Mean Sq      F N.Perm Pr(>F)    
Groups    11 1.13902 0.103547 37.336    999  0.001 ***
Residuals 71 0.19691 0.002773                         

permutest(betadisper(bray_dist_unrare.0days, sample_data(ps.unrare.0days)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df    Sum Sq   Mean Sq      F N.Perm Pr(>F)
Groups     3 0.0047671 0.0015890 1.3006    999  0.308
Residuals 24 0.0293211 0.0012217 

permutest(betadisper(bray_dist_unrare.1days, sample_data(ps.unrare.1days)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df  Sum Sq  Mean Sq      F N.Perm Pr(>F)    
Groups     3 0.27241 0.090803 20.728    999  0.001 ***
Residuals 23 0.10076 0.004381                         

permutest(betadisper(bray_dist_unrare.4days, sample_data(ps.unrare.4days)$Treatment, type=c("centroid")))
##### Response: Distances
          Df  Sum Sq  Mean Sq      F N.Perm Pr(>F)    
Groups     3 0.54016 0.180055 64.659    999  0.001 ***
Residuals 24 0.06683 0.002785                         

permutest(betadisper(bray_dist_unrare.N, sample_data(ps.unrare.N)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df   Sum Sq   Mean Sq      F N.Perm Pr(>F)
Groups     2 0.010423 0.0052117 1.8649    999  0.158
Residuals 18 0.050303 0.0027946 

permutest(betadisper(bray_dist_unrare.H, sample_data(ps.unrare.H)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df    Sum Sq    Mean Sq      F N.Perm Pr(>F)
Groups     2 0.0000894 0.00004468 0.0327    999  0.976
Residuals 18 0.0245653 0.00136474    

permutest(betadisper(bray_dist_unrare.V, sample_data(ps.unrare.V)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df   Sum Sq  Mean Sq      F N.Perm Pr(>F)    
Groups     2 0.223770 0.111885 67.066    999  0.001 ***
Residuals 17 0.028361 0.001668                         

permutest(betadisper(bray_dist_unrare.B, sample_data(ps.unrare.B)$TreatTime, type=c("centroid")))
##### Response: Distances
          Df  Sum Sq  Mean Sq      F N.Perm Pr(>F)    
Groups     2 0.43507 0.217534 41.797    999  0.001 ***
Residuals 18 0.09368 0.005205                         
```