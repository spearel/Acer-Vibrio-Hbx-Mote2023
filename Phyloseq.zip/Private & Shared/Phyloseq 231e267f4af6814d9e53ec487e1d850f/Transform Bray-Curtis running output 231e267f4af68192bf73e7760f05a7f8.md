# Transform Bray-Curtis running output

```jsx
#Run 0 stress 0.05800643 
#Run 1 stress 0.05796559 
... New best solution
... Procrustes: rmse 0.03778097  max resid 0.2978007 
Run 2 stress 0.07544318 
Run 3 stress 0.06447216 
Run 4 stress 0.05039294 
... New best solution
... Procrustes: rmse 0.05996353  max resid 0.2381086 
Run 5 stress 0.07265612 
Run 6 stress 0.0649022 
Run 7 stress 0.06699363 
Run 8 stress 0.07162895 
Run 9 stress 0.06420852 
Run 10 stress 0.06840173 
Run 11 stress 0.06792344 
Run 12 stress 0.06307652 
Run 13 stress 0.0620749 
Run 14 stress 0.06689486 
Run 15 stress 0.05063039 
... Procrustes: rmse 0.01305264  max resid 0.1075294 
Run 16 stress 0.05809901 
Run 17 stress 0.07404001 
Run 18 stress 0.07635064 
Run 19 stress 0.0741348 
Run 20 stress 0.0603726 
*** Best solution was not repeated -- monoMDS stopping criteria:
    18: no. of iterations >= maxit
     2: stress ratio > sratmax
    
```